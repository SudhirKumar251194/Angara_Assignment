package TestPackage;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class AngaraAssignment 

{

	public static void main(String[] args) throws InterruptedException 
	
	{
		
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://www.angara.in/");
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1000));
		
		WebElement popupclose = driver.findElement(By.xpath("//body/div[13]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/*[1]"));
		popupclose.click();
		
		WebElement ring = driver.findElement(By.linkText("Rings"));
		ring.click();
		
		WebElement firstitem = driver.findElement(By.xpath("(//div[@class='spf-col-xl-3 spf-col-lg-4 spf-col-md-4 spf-col-sm-4 spf-col-6'])[1]"));
		firstitem.click();
		
		WebElement choosesize = driver.findElement(By.xpath("//span[contains(text(),'Please choose')]"));
		choosesize.click();
		
		WebElement seven = driver.findElement(By.partialLinkText("7"));
		seven.click();
		
		WebElement addtocart = driver.findElement(By.xpath("//input[@id='add-to-card-btn']"));
		addtocart.click();
		
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		
		WebElement checkout;
		
		checkout = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='checkout']")));
		
		checkout.click();
		
		WebElement email = driver.findElement(By.xpath("//input[@id='email']"));
		email.sendKeys("sudhir@mailinator.com");
		
		WebElement firstname = driver.findElement(By.xpath("//input[@id='TextField0']"));
		firstname.sendKeys("Sudhir");
		
		
		WebElement lastname = driver.findElement(By.xpath("//input[@id='TextField1']"));
		lastname.sendKeys("Kumar");
		
		WebElement address = driver.findElement(By.xpath("//input[@id='shipping-address1']"));
		address.sendKeys("Q.no.116, Near Jhandewalan");
		
		WebElement city = driver.findElement(By.xpath("//input[@id='TextField3']"));
		city.sendKeys("Delhi");
		
		WebElement pincode = driver.findElement(By.xpath("//input[@id='TextField4']"));
		pincode.sendKeys("110006");
		
		WebElement phone = driver.findElement(By.xpath("//input[@id='TextField5']"));
		phone.sendKeys("8888888888");
		
		WebElement continueship = driver.findElement(By.xpath("//body/div[@id='app']/div[1]//div[2]/div[1]//main[1]/div[1]//form[1]/div[1]//div[2]/div[1]/div[2]/div[1]/button[1]"));
		continueship.click();
		
		
		WebElement continuepayment;
		
		continuepayment = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//body/div[@id='app']/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/main[1]/div[1]/div[1]/div[1]/div[1]/div[2]/form[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/button[1]")));
		
		continuepayment.click();
		
		WebElement paynow = driver.findElement(By.xpath("//body/div[@id='app']/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/main[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/button[1]"));
		paynow.click();
		
		
	
		System.out.println("Since I don't have a testing card, so don't pay");
		
		
		
		
		
	}

}
